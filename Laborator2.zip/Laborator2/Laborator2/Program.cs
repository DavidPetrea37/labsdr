﻿using System;
using System.Collections.Generic;
using Recombee.ApiClient;
using Recombee.ApiClient.ApiRequests;
using Recombee.ApiClient.Bindings;

namespace RecombeeUploader
{
    public class Program
    {
        static void Main(string[] args)
        {
            var client = new RecombeeClient(
                "davidpetrea-laborator-sdr",
                "a2k0uXltCQwrg8oXpmtzOmG7NQjVhWWY14LMzZX7avVSFjHHLt7q8rY91356NARn"
            );

            var users = GenerateUsers(25);

            Console.WriteLine("Începem adăugarea utilizatorilor în Recombee...\n");

            foreach (var user in users)
            {
                try
                {
                    var userValues = new Dictionary<string, object>
                    {
                        { "name", user.FullName },
                        { "email", user.Email },
                        { "phone", user.Phone },
                        { "location", user.Location }
                    };

                    client.Send(new SetUserValues(user.Id, userValues, cascadeCreate: true));

                    Console.WriteLine($"Adăugat: {user.FullName} ({user.Id})");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Eroare la utilizatorul {user.Id}: {ex.Message}");
                }
            }

            Console.WriteLine("\nProces terminat. Toți utilizatorii au fost trimiși către Recombee.");
        }

        public static List<User> GenerateUsers(int count)
        {
            var random = new Random();
            var users = new List<User>();

            string[] firstNames = { "Andrei", "Maria", "Alex", "Ioana", "Mihai", "Elena", "Vlad", "Ana", "Cristian", "Raluca" };
            string[] lastNames = { "Popescu", "Ionescu", "Dumitrescu", "Stan", "Georgescu", "Marin", "Radu", "Petrescu", "Tudor", "Iliescu" };
            string[] cities = { "București", "Cluj-Napoca", "Timișoara", "Iași", "Brașov", "Constanța", "Sibiu", "Oradea" };

            for (int i = 0; i < count; i++)
            {
                string first = firstNames[random.Next(firstNames.Length)];
                string last = lastNames[random.Next(lastNames.Length)];
                string fullName = $"{first} {last}";
                string email = $"{first.ToLower()}.{last.ToLower()}{random.Next(100, 999)}@example.com";
                string phone = $"+40{random.Next(700000000, 799999999)}";
                string location = cities[random.Next(cities.Length)];

                users.Add(new User
                {
                    Id = $"user-{i + 1}",
                    FullName = fullName,
                    Email = email,
                    Phone = phone,
                    Location = location
                });
            }

            return users;
        }
    }

    public class User
    {
        public string Id { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Location { get; set; }
    }
}
